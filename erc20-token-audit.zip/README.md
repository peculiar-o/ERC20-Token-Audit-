# ERC-20 Token Audit Report  
**Auditor**: Chilaka Oluomachukwu Peculiar  
**GitHub**: [@yourusername](https://github.com/yourusername)  

## Findings  
| Severity | Issue          | Fix |  
|----------|----------------|-----|  
| High     | Reentrancy     | Added `nonReentrant` modifier |  
| Medium   | Zero-address   | `require(to != address(0))` |  
