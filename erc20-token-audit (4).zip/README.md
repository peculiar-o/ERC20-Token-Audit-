# ERC-20 Token Audit Report  
**Auditor**: Chilaka Oluomachukwu Peculiar  
**GitHub**: [@yourusername](https://github.com/yourusername)  

## Findings  
| Severity | Issue          | Fix |  
|----------|----------------|-----|  
| High     | Reentrancy     | Added `nonReentrant` modifier |  
| High     | Integer Overflow | Integrated `SafeMath` |  
| Medium   | Gas Inefficiency | Optimized storage usage |  

## Summary  
This project audits an ERC-20 smart contract, identifying and mitigating critical vulnerabilities.  
